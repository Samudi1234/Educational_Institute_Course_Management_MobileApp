package com.example.mad_cw.course.admin;

public class SendAddCourseNotification {
}
